"""Correlated-gene simulation study (Python version of the R script
inst/scripts/simulation_correlated.R in hetNSC).

  python simulation_correlated.py 5 1     # heteroscedastic design (class B correlated), iter 1
  python simulation_correlated.py 4 1     # homoscedastic design (both classes correlated)

Each `iter` is one simulated dataset analysed with 100 runs per classifier;
run different iters as separate jobs. NumPy's RNG differs from R's, so the
datasets are not the same as the ones used for the paper.
"""
import sys
from pathlib import Path

import numpy as np

import hetnsc as h

example = int(sys.argv[1]) if len(sys.argv) > 1 else 5
it = int(sys.argv[2]) if len(sys.argv) > 2 else 1
correlated = "both" if example == 4 else "B"
signals = range(9, 24) if example == 4 else range(9, 21)
out = Path(f"hetnsc_example{example}_results")
out.mkdir(exist_ok=True)

rows = []
for a in signals:
    d = h.simulate_hetero_data(15, 20, 50, 50, ngene=20, p=10000, a=a,
                               correlated=correlated, random_state=it * 8900)
    res = h.compare_nsc(d["X_train"], d["y_train"], d["X_test"], d["y_test"],
                        n_runs=100)
    s = res.summary()
    rows.append({"a": a, "iter": it,
                 **{f"error_{m}": e for m, e in zip(res.methods, res.errors.mean(0))},
                 **{f"BalAcc_{m}": 100 * b for m, b in
                    zip(res.methods, np.asarray(s["balanced_accuracy"]))}})
    print(a, rows[-1], flush=True)

import csv
with open(out / f"iter{it}_results.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0]))
    w.writeheader()
    w.writerows(rows)
