"""Simulation design with correlated informative genes."""

from __future__ import annotations

import numpy as np


def simulate_hetero_data(ntr1: int, ntr2: int, nte1: int, nte2: int, *,
                         ngene: int = 20, p: int = 10000, s=None,
                         a: float = 10.0, rho: float = 0.95,
                         correlated: str = "B", random_state=None) -> dict:
    """Simulate two-class data with correlated informative genes.

    Class A has mean zero for every gene; class B has mean ``a/10 * i`` for
    the first ``ngene`` (informative) genes and zero elsewhere. Every
    non-informative gene ``i`` is independent with standard deviation
    ``s[i]`` in both classes.

    The informative genes are drawn from a multivariate normal distribution
    with covariance ``Sigma = v v'``, ``v_i = sqrt(rho**(i-1)) * s_i``, i.e.
    ``Sigma_ij = rho**((i+j-2)/2) * s_i * s_j`` -- the matrix used for the
    results in the paper. It has rank one (the informative genes are perfectly
    correlated) and gene ``i`` has variance ``rho**(i-1) * s_i**2``.

    Parameters
    ----------
    ntr1, ntr2, nte1, nte2 : training / test sizes of classes A and B.
    ngene : number of informative genes.
    p : total number of genes.
    s : gene standard deviations (length p); default cycles 1, 2, ..., 20.
    a : signal strength.
    rho : correlation parameter (0.95 in the paper).
    correlated : ``"B"`` (only class B correlated; class A independent --
        heteroscedastic design) or ``"both"`` (both classes share Sigma --
        homoscedastic design).
    random_state : seed or numpy Generator.

    Returns
    -------
    dict with ``X_train``, ``X_test`` (samples x genes) and ``y_train``,
    ``y_test`` (arrays of ``"A"``/``"B"``).

    Notes
    -----
    NumPy's random number generator differs from R's, so the same seed does
    not give the same data as the R package.
    """
    rng = np.random.default_rng(random_state)
    if correlated not in ("B", "both"):
        raise ValueError('correlated must be "B" or "both"')
    if s is None:
        s = np.resize(np.arange(1, 21, dtype=float), p)
    s = np.asarray(s, dtype=float)
    if len(s) != p or not (1 <= ngene < p):
        raise ValueError("need len(s) == p and 1 <= ngene < p")
    N1, N2 = ntr1 + nte1, ntr2 + nte2
    inf = np.arange(1, ngene + 1)
    mu2 = a / 10 * inf
    v = np.sqrt(rho ** (inf - 1)) * s[:ngene]
    Sigma = np.outer(v, v)

    def mvn(n, mu):
        return rng.multivariate_normal(mu, Sigma, size=n, method="eigh")

    x2 = np.empty((N2, p))
    x2[:, ngene:] = rng.standard_normal((N2, p - ngene)) * s[ngene:]
    x2[:, :ngene] = mvn(N2, mu2)
    x1 = rng.standard_normal((N1, p)) * s
    if correlated == "both":
        x1[:, :ngene] = mvn(N1, np.zeros(ngene))

    return {
        "X_train": np.vstack([x1[:ntr1], x2[:ntr2]]),
        "y_train": np.array(["A"] * ntr1 + ["B"] * ntr2),
        "X_test": np.vstack([x1[ntr1:], x2[ntr2:]]),
        "y_test": np.array(["A"] * nte1 + ["B"] * nte2),
    }
