"""Repeated-run comparison of homoscedastic and heteroscedastic NSC."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional, Sequence

import numpy as np

from ._core import method_label
from .metrics import balanced_accuracy, confusion_matrix, per_class_recall
from .model import HNSCClassifier, _prepare


@dataclass
class ComparisonResult:
    """Result of :func:`compare_nsc`."""

    methods: list
    classes: np.ndarray
    errors: np.ndarray            # n_runs x n_methods test error rates
    n_genes: np.ndarray           # n_runs x n_methods genes used
    cm_list: dict                 # method -> list of per-run confusion matrices
    n: int                        # training sample size

    @property
    def error(self) -> dict:
        return dict(zip(self.methods, self.errors.mean(axis=0)))

    @property
    def ave_num_genes(self) -> dict:
        return dict(zip(self.methods, self.n_genes.mean(axis=0)))

    def mean_cm(self, method: str) -> np.ndarray:
        """Confusion matrix averaged over runs."""
        return np.mean(self.cm_list[method], axis=0)

    def summary(self):
        """Per method: mean / sd test error, balanced accuracy (from the
        run-averaged confusion matrix, as in the paper) and mean genes used.
        Returns a pandas DataFrame if pandas is installed, else a dict."""
        out = {
            "method": list(self.methods),
            "error": self.errors.mean(axis=0),
            "error_sd": self.errors.std(axis=0, ddof=1) if len(self.errors) > 1
            else np.full(len(self.methods), np.nan),
            "balanced_accuracy": np.array(
                [balanced_accuracy(self.mean_cm(m)) for m in self.methods]),
            "genes": self.n_genes.mean(axis=0),
        }
        return _maybe_frame(out)

    def recall_table(self):
        """Recall of every class (rows) for every method (columns)."""
        out = {"class": list(self.classes)}
        for m in self.methods:
            out[f"recall_{m}"] = per_class_recall(self.mean_cm(m))
        return _maybe_frame(out)

    def __repr__(self) -> str:
        lines = [f"NSC comparison: {self.errors.shape[0]} runs, "
                 f"{len(self.classes)} classes, {self.n} training samples",
                 f"  {'method':<6} {'error':>8} {'bal.acc':>8} {'genes':>9}"]
        for j, m in enumerate(self.methods):
            lines.append(f"  {m:<6} {self.errors[:, j].mean():8.4f} "
                         f"{balanced_accuracy(self.mean_cm(m)):8.4f} "
                         f"{self.n_genes[:, j].mean():9.2f}")
        return "\n".join(lines)


def _maybe_frame(d):
    try:
        import pandas as pd
        return pd.DataFrame(d)
    except ImportError:  # pragma: no cover
        return d


def compare_nsc(X, y, X_test, y_test, n_runs: int = 100,
                thresholding: Sequence[str] = ("hard", "soft", "order"),
                seed_fun: Optional[Callable[[int], int]] = lambda i: 1000 + 10 * i,
                verbose: bool = True) -> ComparisonResult:
    """Evaluation protocol of the paper.

    For each thresholding rule, the homoscedastic classifier (STh/HTh/OTh) and
    its heteroscedastic counterpart (STh3/HTh3/OTh3) are fitted ``n_runs``
    times, each time with the threshold chosen by deep CV after a random
    reordering of the training samples (which changes the CV folds), and
    evaluated on the test set. As in the paper's script, the reordering is
    cumulative across runs and thresholding rules, and run ``i`` (1-based)
    uses seed ``seed_fun(i)`` (default ``1000 + 10 i``).

    X and X_test are samples x genes.
    """
    _prepare(X, y)
    X = np.asarray(X, dtype=float)
    y = np.asarray(y)
    X_test = np.asarray(X_test, dtype=float)
    y_test = np.asarray(y_test).astype(str)
    if X_test.shape[1] != X.shape[1]:
        raise ValueError("X_test must have the same genes (columns) as X.")
    classes = np.unique(y.astype(str))
    methods = []
    for t in thresholding:
        methods += [method_label(t, "homo"), method_label(t, "hetero")]
    errors = np.full((n_runs, len(methods)), np.nan)
    n_genes = np.full((n_runs, len(methods)), np.nan)
    cm_list = {m: [None] * n_runs for m in methods}

    for t in thresholding:
        for itr in range(1, n_runs + 1):
            rng = np.random.default_rng(seed_fun(itr) if seed_fun else None)
            order = rng.permutation(len(y))
            X, y = X[order], y[order]
            for v in ("homo", "hetero"):
                lab = method_label(t, v)
                j = methods.index(lab)
                clf = HNSCClassifier(t, v, random_state=rng).fit(X, y)
                pred = clf.predict(X_test).astype(str)
                cm_list[lab][itr - 1] = confusion_matrix(y_test, pred, classes)
                n_genes[itr - 1, j] = clf.n_genes_
                errors[itr - 1, j] = np.mean(pred != y_test)
            if verbose:
                done = ~np.isnan(errors[itr - 1])
                msg = " ".join(f"{m}={e:.3f}" for m, e in
                               zip(np.array(methods)[done], errors[itr - 1][done]))
                print(f"{t:<5} run {itr}/{n_runs}: {msg}", flush=True)

    return ComparisonResult(methods, classes, errors, n_genes, cm_list, len(y))
