"""Core computational engine shared by the six NSC classifiers.

This is a line-by-line translation of the R package ``hetNSC`` (itself derived
from ``pamr`` and the research code of Sahtout and Wang). Internally all
expression matrices are **genes x samples** (p x n), as in R, so that the
arithmetic follows the R code; the public API uses samples x genes.

Homoscedastic branch:  soft shrinkage = original PAM (STh, Tibshirani et al.
2002); hard / order shrinkage = HTh / OTh (Sahtout, Wang and Ghimire 2024).
Heteroscedastic branch: STh3, HTh3, OTh3 (Sahtout and Wang).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import numpy as np

METHODS = ("soft", "hard", "order")
VARIANCES = ("hetero", "homo")

_LABELS = {
    ("soft", "homo"): "STh",
    ("hard", "homo"): "HTh",
    ("order", "homo"): "OTh",
    ("soft", "hetero"): "STh3",
    ("hard", "hetero"): "HTh3",
    ("order", "hetero"): "OTh3",
}
_FROM_LABEL = {v: k for k, v in _LABELS.items()}


def method_label(method: str, variance: str) -> str:
    return _LABELS[(method, variance)]


def resolve_method(method: str, variance: str = "hetero") -> tuple[str, str]:
    """Accept ``"hard"``/``"soft"``/``"order"`` + variance, or a paper label."""
    if method in _FROM_LABEL:
        return _FROM_LABEL[method]
    if method not in METHODS:
        raise ValueError(
            f"method must be one of {METHODS} or a label {tuple(_FROM_LABEL)}; "
            f"got {method!r}")
    if variance not in VARIANCES:
        raise ValueError(f"variance must be one of {VARIANCES}; got {variance!r}")
    return method, variance


# --------------------------------------------------------------------------
# R-compatible small helpers
# --------------------------------------------------------------------------

def r_seq(start: float, stop: float, length_out: int) -> np.ndarray:
    """R's ``seq(from, to, length.out = n)`` with identical floating point."""
    n = int(length_out)
    if n <= 0:
        return np.empty(0)
    if n == 1:
        return np.array([float(start)])
    if n == 2:
        return np.array([float(start), float(stop)])
    if start == stop:
        return np.full(n, float(start))
    n1 = n - 1
    by = (stop - start) / n1
    mid = start + np.arange(1, n1) * by
    return np.concatenate(([float(start)], mid, [float(stop)]))


def r_round(x):
    """R's ``round(x)`` (round half to even)."""
    return np.round(x)


def r_quantile(x: np.ndarray, prob: float) -> float:
    """R's default (type 7) quantile."""
    return float(np.quantile(x, prob, method="linear"))


def rank_average(a: np.ndarray) -> np.ndarray:
    """R's ``rank()`` (ties averaged), returned in the shape of ``a``."""
    flat = np.ravel(a)
    sorter = np.argsort(flat, kind="mergesort")
    inv = np.empty(sorter.size, dtype=np.intp)
    inv[sorter] = np.arange(sorter.size)
    s = flat[sorter]
    obs = np.r_[True, s[1:] != s[:-1]]
    dense = obs.cumsum()[inv]
    count = np.r_[np.nonzero(obs)[0], len(obs)]
    return (0.5 * (count[dense] + count[dense - 1] + 1)).reshape(np.shape(a))


def last_which_min(x) -> int:
    """Index of the minimum; among ties the LAST one (0-based)."""
    x = np.asarray(x)
    return len(x) - 1 - int(np.argmin(x[::-1]))


def safe_exp(x):
    return np.exp(np.sign(x) * np.minimum(np.abs(x), 500))


# --------------------------------------------------------------------------
# thresholding rules -- each returns (shrunk delta, number of genes kept)
# --------------------------------------------------------------------------

def soft_shrink(delta, threshold):
    dif = np.abs(delta) - threshold
    keep = dif > 0
    out = np.sign(delta) * dif * keep
    return out, int(np.sum(keep.sum(axis=1) > 0))


def hard_shrink(delta, threshold):
    dif = np.abs(delta) - threshold
    keep = dif > 0
    out = delta * keep
    return out, int(np.sum(keep.sum(axis=1) > 0))


def order_shrink(delta, threshold):
    """Keep the ``threshold`` largest |d_ik| over all genes and classes."""
    dif = rank_average(np.abs(delta)) - (delta.size - threshold)
    keep = dif > 0
    out = delta * keep
    return out, int(np.sum(keep.sum(axis=1) > 0))


_SHRINK = {"soft": soft_shrink, "hard": hard_shrink, "order": order_shrink}


# --------------------------------------------------------------------------
# discriminant functions (return -delta_k(x*)/2 up to a constant: larger wins)
# --------------------------------------------------------------------------

def diag_disc(x, centroids, prior, posid):
    """Pooled-variance discriminant (pamr's ``diag.disc``); x, centroids are
    already standardised by (s_i + s_0). Shapes: x p x m, centroids p x K."""
    if not np.any(posid):
        return np.tile(np.log(prior), (x.shape[1], 1))
    c = centroids[posid, :]
    xs = x[posid, :]
    dd = xs.T @ c
    dd0 = (np.ones(c.shape[0]) @ (c ** 2)) / 2 - np.log(prior)
    return dd - dd0


def diag_disc_heter(x, centroids, prior, posid, sik2):
    """Heteroscedastic discriminant, eq. (2.9). x = x* - xbar (unscaled);
    centroids = xbar'_k - xbar; sik2 = s_ik^2 + s_0k^2 (p x K)."""
    if not np.any(posid):
        return np.tile(np.log(prior), (x.shape[1], 1))
    c = centroids[posid, :]
    xs = x[posid, :]
    s2 = sik2[posid, :]
    ones = np.ones(c.shape[0])
    dd0 = (ones @ (c ** 2 / s2)) / 2 - np.log(prior) + ones @ np.log(np.sqrt(2 * np.pi * s2))
    dd = xs.T @ (c / s2)
    K = c.shape[1]
    disc = np.empty((xs.shape[1], K))
    x2 = xs ** 2
    for k in range(K):
        disc[:, k] = ((x2 / s2[:, k][:, None]).T @ ones) / 2
    return dd - disc - dd0


# --------------------------------------------------------------------------
# fitting
# --------------------------------------------------------------------------

@dataclass
class NSCPath:
    """An NSC classifier fitted over a grid of thresholds (genes x samples
    internally). Created by :func:`hetnsc.train`."""

    method: str
    variance: str
    classes: np.ndarray
    threshold: np.ndarray
    nonzero: np.ndarray
    centroids: np.ndarray            # p x K class centroids
    centroid_overall: np.ndarray     # p
    sd: np.ndarray                   # p (homo) or p x K (hetero)
    sik2: Optional[np.ndarray]       # p x K (hetero only)
    offset: np.ndarray
    delta: np.ndarray                # unshrunken d_ik, p x K
    se_scale: np.ndarray
    threshold_scale: np.ndarray
    prior: np.ndarray
    sign_contrast: str
    offset_percent: float
    errors: Optional[np.ndarray] = None   # training resubstitution errors
    yhat: Optional[np.ndarray] = field(default=None, repr=False)
    prob: Optional[np.ndarray] = field(default=None, repr=False)

    @property
    def label(self) -> str:
        return method_label(self.method, self.variance)

    # -- shrunken quantities at one threshold --------------------------------
    def shrunken_delta(self, threshold: float) -> np.ndarray:
        if self.variance == "homo":
            delta = ((self.centroids - self.centroid_overall[:, None])
                     / self.sd[:, None]) / (self.threshold_scale * self.se_scale)
        else:
            delta = (self.centroids - self.centroid_overall[:, None]) / self.sd
        if self.sign_contrast == "positive":
            delta = delta * (delta > 0)
        elif self.sign_contrast == "negative":
            delta = delta * (delta < 0)
        ds, _ = _SHRINK[self.method](delta, threshold)
        if self.variance == "homo":
            ds = ds / (1 / (self.threshold_scale * self.se_scale))
        return ds

    def scores(self, x_gxs: np.ndarray, threshold: float) -> np.ndarray:
        """Discriminant scores (m x K) for new data given as genes x samples."""
        ds = self.shrunken_delta(threshold)
        posid = (np.abs(ds) @ np.ones(ds.shape[1])) > 0
        if self.variance == "homo":
            xs = (x_gxs - self.centroid_overall[:, None]) / self.sd[:, None]
            return diag_disc(xs, ds, self.prior, posid)
        return diag_disc_heter(x_gxs - self.centroid_overall[:, None],
                               ds * self.sd, self.prior, posid, self.sik2)


def nsc_fit(x, y, K, xtest=None, ytest=None, *, method="hard",
            variance="hetero", threshold=None, n_threshold=30,
            offset_percent=50.0, prior=None, se_scale=None,
            remove_zeros=True, sign_contrast="both", compute_prob=True,
            classes=None) -> NSCPath:
    """Fit an NSC classifier over a grid of thresholds.

    x, xtest: p x n float arrays (genes x samples). y, ytest: integer class
    codes 0..K-1. If xtest is None the training data are used as test data.
    """
    x = np.asarray(x, dtype=float)
    y = np.asarray(y)
    n_class = np.bincount(y, minlength=K).astype(float)
    if prior is None:
        prior = n_class / len(y)
    prior = np.asarray(prior, dtype=float)
    if variance == "hetero" and n_class.min() < 2:
        raise ValueError("The heteroscedastic classifiers need at least 2 "
                         "training samples per class.")
    if xtest is None:
        xtest, ytest = x, y
    n = n_class.sum()
    p = x.shape[0]

    Y = np.zeros((len(y), K))
    Y[np.arange(len(y)), y] = 1.0

    centroids = (x @ Y) / n_class
    xdif = x - centroids @ Y.T
    threshold_scale = np.ones(K)
    sik2 = None

    if variance == "homo":
        # pooled within-class sd + s_0  (eq. 2.3)
        sd = np.sqrt((xdif ** 2) @ np.full(len(y), 1 / (n - K)))
        offset = np.array(r_quantile(sd, offset_percent / 100))
        sd = sd + offset
        if se_scale is None:
            se_scale = np.sqrt(1 / n_class - 1 / n)
    else:
        # class-specific variances s_ik^2 + s_0k^2  (eq. 2.6-2.7)
        sik2 = ((xdif ** 2) @ Y) / (n_class - 1)
        offset = np.array([r_quantile(sik2[:, k], offset_percent / 100)
                           for k in range(K)])
        sik2 = sik2 - (-offset)
        sd = sik2 / (1 / (1 / n_class - 2 / n)) + \
            ((sik2 / (1 / n_class)) @ np.full(K, 1 / n ** 2))[:, None]
        sd = np.sqrt(sd)
        if se_scale is None:
            se_scale = np.ones(1)
    se_scale = np.asarray(se_scale, dtype=float)

    centroid_overall = x @ np.full(len(y), 1 / n)
    sd_b = sd[:, None] if variance == "homo" else sd
    delta = (centroids - centroid_overall[:, None]) / sd_b
    if variance == "homo":
        delta = delta / (threshold_scale * se_scale)
    if sign_contrast == "positive":
        delta = delta * (delta > 0)
    elif sign_contrast == "negative":
        delta = delta * (delta < 0)

    if threshold is not None:
        threshold = np.atleast_1d(np.asarray(threshold, dtype=float))
        n_threshold = len(threshold)
    elif method == "order":
        mx = r_round(delta.size / 4)
        threshold = r_round(r_seq(mx, 1, n_threshold))
    else:
        threshold = r_seq(0, np.max(np.abs(delta)), n_threshold)

    shrink = _SHRINK[method]
    ntest = xtest.shape[1]
    nonzero = np.zeros(n_threshold, dtype=int)
    errors = np.zeros(n_threshold, dtype=int)
    yhat = np.empty((ntest, n_threshold), dtype=int)
    prob = np.zeros((ntest, K, n_threshold)) if compute_prob else None
    if variance == "homo":
        xs = (xtest - centroid_overall[:, None]) / sd[:, None]
    else:
        xs = xtest - centroid_overall[:, None]

    ones_K = np.ones(K)
    for ii in range(n_threshold):
        ds, nonzero[ii] = shrink(delta, threshold[ii])
        if variance == "homo":
            ds = ds / (1 / (threshold_scale * se_scale))
            posid = (np.abs(ds) @ ones_K) > 0
            dd = diag_disc(xs, ds, prior, posid)
        else:
            posid = (np.abs(ds) @ ones_K) > 0
            dd = diag_disc_heter(xs, ds * sd, prior, posid, sik2)
        cls = np.argmax(dd, axis=1)
        yhat[:, ii] = cls
        if compute_prob:
            e = safe_exp(dd)
            prob[:, :, ii] = e / (e @ ones_K)[:, None]
        if ytest is not None:
            errors[ii] = np.sum(cls != ytest)

    if remove_zeros:
        z = np.nonzero(nonzero == 0)[0]
        n_keep = int(z[0]) + 1 if z.size else n_threshold
    else:
        n_keep = n_threshold
    keep = slice(0, n_keep)
    return NSCPath(
        method=method, variance=variance,
        classes=np.asarray(classes) if classes is not None else np.arange(K),
        threshold=threshold[keep], nonzero=nonzero[keep],
        centroids=centroids, centroid_overall=centroid_overall, sd=sd,
        sik2=sik2, offset=np.atleast_1d(offset), delta=delta,
        se_scale=se_scale, threshold_scale=threshold_scale, prior=prior,
        sign_contrast=sign_contrast, offset_percent=offset_percent,
        errors=errors[keep] if ytest is not None else None,
        yhat=yhat[:, keep], prob=prob[:, :, keep] if compute_prob else None,
    )
