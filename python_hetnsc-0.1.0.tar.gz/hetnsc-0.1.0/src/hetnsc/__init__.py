"""hetnsc: heteroscedastic nearest shrunken centroid classification.

Six nearest shrunken centroid (NSC) classifiers for high-dimensional data:

======  ========  ==============  ==========================================
label   method    variance        reference
======  ========  ==============  ==========================================
STh     soft      homo (pooled)   original PAM (Tibshirani et al. 2002)
HTh     hard      homo (pooled)   Sahtout, Wang and Ghimire (2024)
OTh     order     homo (pooled)   Sahtout, Wang and Ghimire (2024)
STh3    soft      hetero          Sahtout and Wang
HTh3    hard      hetero          Sahtout and Wang
OTh3    order     hetero          Sahtout and Wang
======  ========  ==============  ==========================================

Data layout: samples in rows, genes in columns (scikit-learn convention).
Python port of the R package ``hetNSC``.
"""

from ._core import NSCPath
from ._cv import CVResult, Selection, balanced_folds
from .compare import ComparisonResult, compare_nsc
from .metrics import (balanced_accuracy, compute_rho2, confusion_matrix,
                      per_class_recall)
from .model import HNSCClassifier, cross_validate, select_threshold, train
from .simulate import simulate_hetero_data

__version__ = "0.1.0"


def methods():
    """Table of the six classifiers: (label, method, variance, reference)."""
    return [
        ("STh", "soft", "homo", "Tibshirani et al. (2002), original PAM"),
        ("HTh", "hard", "homo", "Sahtout, Wang and Ghimire (2024)"),
        ("OTh", "order", "homo", "Sahtout, Wang and Ghimire (2024)"),
        ("STh3", "soft", "hetero", "Sahtout and Wang"),
        ("HTh3", "hard", "hetero", "Sahtout and Wang"),
        ("OTh3", "order", "hetero", "Sahtout and Wang"),
    ]


__all__ = [
    "HNSCClassifier", "train", "cross_validate", "select_threshold",
    "balanced_folds", "compare_nsc", "simulate_hetero_data",
    "confusion_matrix", "per_class_recall", "balanced_accuracy",
    "compute_rho2", "methods", "NSCPath", "CVResult", "Selection",
    "ComparisonResult",
]
