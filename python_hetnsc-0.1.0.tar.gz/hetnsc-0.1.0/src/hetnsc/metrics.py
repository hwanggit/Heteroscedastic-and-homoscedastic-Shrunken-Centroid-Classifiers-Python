"""Class-level performance metrics and the relative-heterogeneity diagnostic."""

from __future__ import annotations

import numpy as np


def confusion_matrix(y_true, y_pred, classes=None) -> np.ndarray:
    """K x K confusion matrix: rows = true class, columns = predicted class.
    Labels not in ``classes`` are ignored."""
    y_true = np.asarray(y_true).astype(str)
    y_pred = np.asarray(y_pred).astype(str)
    if classes is None:
        classes = np.unique(y_true)
    classes = np.asarray(classes).astype(str)
    idx = {c: i for i, c in enumerate(classes)}
    cm = np.zeros((len(classes), len(classes)), dtype=int)
    for t, p in zip(y_true, y_pred):
        if t in idx and p in idx:
            cm[idx[t], idx[p]] += 1
    return cm


def per_class_recall(cm) -> np.ndarray:
    """Recall (sensitivity) of every class: diagonal / row totals."""
    cm = np.asarray(cm, dtype=float)
    return np.diag(cm) / np.maximum(cm.sum(axis=1), 1)


def balanced_accuracy(cm) -> float:
    """Mean of the per-class recalls (macro-averaged recall)."""
    return float(np.mean(per_class_recall(cm)))


def compute_rho2(X_train, y_train, X_test=None, y_test=None,
                 summary_fn=np.median) -> dict:
    """Empirical relative heterogeneity rho_k^2 and the crossover check.

    rho_k^2 = (sigma_k^2 / sigma_bar^2 - 1)^2 with
    sigma_bar^2 = sum_k n_k sigma_k^2 / n (Section 2.4 of Sahtout and Wang),
    summarised across genes and compared with the bound 2 / (n_k - 1)
    (eq. 2.11 with w_k = 1). ``crossover_met`` True means the class-specific
    variance estimate is expected to have lower MSE than the pooled one.

    X_train / X_test are samples x genes. The optional test data are used only
    to estimate class variances; the weights n_k come from the training
    labels.

    Returns a dict of arrays: class, n_k, sigma2_hat, sigma_bar2, rho2_hat,
    threshold, crossover_met.
    """
    X_train = np.asarray(X_train, dtype=float)
    y_train = np.asarray(y_train).astype(str)
    if X_test is None:
        X_test, y_test = X_train, y_train
    X_test = np.asarray(X_test, dtype=float)
    y_test = np.asarray(y_test).astype(str)
    classes = np.unique(y_train)
    n_k = np.array([np.sum(y_train == k) for k in classes], dtype=float)
    n = n_k.sum()
    s2 = np.column_stack([
        X_test[y_test == k].var(axis=0, ddof=1) if np.sum(y_test == k) >= 2
        else np.full(X_test.shape[1], np.nan) for k in classes])
    sigma_bar2 = s2 @ n_k / n
    rho2 = (s2 / sigma_bar2[:, None] - 1) ** 2

    def summ(a):
        return summary_fn(a[~np.isnan(a)]) if np.any(~np.isnan(a)) else np.nan

    rho2_hat = np.array([summ(rho2[:, j]) for j in range(len(classes))])
    with np.errstate(divide="ignore"):
        threshold = np.where(n_k > 1, 2 / (n_k - 1), np.inf)
    return {
        "class": classes,
        "n_k": n_k.astype(int),
        "sigma2_hat": np.round([summ(s2[:, j]) for j in range(len(classes))], 4),
        "sigma_bar2": round(float(summ(sigma_bar2)), 4),
        "rho2_hat": np.round(rho2_hat, 4),
        "threshold": np.round(threshold, 4),
        "crossover_met": rho2_hat > threshold,
    }
