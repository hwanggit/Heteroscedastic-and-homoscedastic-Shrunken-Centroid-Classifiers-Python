"""Public API: functional interface and a scikit-learn style classifier.

Data layout: **samples in rows, genes in columns** (``X`` is n x p), the
scikit-learn convention. (The R package uses genes x samples.)
"""

from __future__ import annotations

from typing import Optional

import numpy as np

from ._core import NSCPath, nsc_fit, resolve_method
from ._cv import CVResult, Selection, cv_path, deep_cv

try:  # optional scikit-learn integration
    from sklearn.base import BaseEstimator as _Base
    from sklearn.base import ClassifierMixin as _Mixin
except ImportError:  # pragma: no cover
    class _Base:  # minimal get_params / set_params
        def get_params(self, deep=True):
            return {k: getattr(self, k) for k in self._param_names}

        def set_params(self, **params):
            for k, v in params.items():
                setattr(self, k, v)
            return self

    class _Mixin:
        def score(self, X, y):
            return float(np.mean(self.predict(X) == np.asarray(y)))


def _prepare(X, y=None):
    X = np.asarray(X, dtype=float)
    if X.ndim != 2:
        raise ValueError("X must be a 2-D array (samples x genes).")
    if not np.all(np.isfinite(X)):
        raise ValueError("X contains missing or infinite values.")
    if y is None:
        return X.T, None, None
    y = np.asarray(y)
    if y.ndim != 1 or len(y) != X.shape[0]:
        if len(y) == X.shape[1]:
            raise ValueError("X must have samples in rows and genes in columns; "
                             "len(y) matches X.shape[1], so try X.T.")
        raise ValueError("len(y) must equal X.shape[0] (number of samples).")
    classes, codes = np.unique(y, return_inverse=True)
    if len(classes) < 2:
        raise ValueError("y must contain at least two classes.")
    return X.T, codes, classes


def _attach_classes(path: NSCPath, classes) -> NSCPath:
    path.classes = classes
    return path


def train(X, y, method: str = "hard", variance: str = "hetero", *,
          threshold=None, n_threshold: int = 30, offset_percent: float = 50.0,
          prior=None, sign_contrast: str = "both",
          remove_zeros: bool = True) -> NSCPath:
    """Fit an NSC classifier over a grid of thresholds.

    Parameters
    ----------
    X : array (n_samples, n_genes)
    y : array (n_samples,) of class labels
    method : ``"hard"``, ``"soft"`` or ``"order"``, or a paper label
        (``"STh"``, ``"HTh"``, ``"OTh"``, ``"STh3"``, ``"HTh3"``, ``"OTh3"``),
        in which case ``variance`` is ignored.
    variance : ``"hetero"`` (class-specific variances; Sahtout and Wang) or
        ``"homo"`` (pooled variance). With ``"homo"``, ``method="soft"`` is the
        original PAM classifier (Tibshirani et al. 2002); ``"hard"`` and
        ``"order"`` are the homoscedastic classifiers of Sahtout, Wang and
        Ghimire (2024).
    threshold : optional sequence of thresholds. Soft/hard: cut-offs on
        |d_ik|. Order: number of largest |d_ik| (over genes and classes) kept.
    n_threshold : size of the default grid.
    offset_percent : percentile used for the stabilising constant s_0 / s_0k.
    prior : class priors (default: training class proportions).
    sign_contrast : ``"both"``, ``"positive"`` or ``"negative"``.
    remove_zeros : drop thresholds after the first one keeping no genes.

    Returns
    -------
    NSCPath
    """
    m, v = resolve_method(method, variance)
    x, codes, classes = _prepare(X, y)
    K = len(classes)
    path = nsc_fit(x, codes, K, method=m, variance=v, threshold=threshold,
                   n_threshold=n_threshold, offset_percent=offset_percent,
                   prior=prior, remove_zeros=remove_zeros,
                   sign_contrast=sign_contrast)
    return _attach_classes(path, classes)


def cross_validate(path: NSCPath, X, y, *, folds=None,
                   random_state=None) -> CVResult:
    """Class-balanced K-fold cross-validation along a fitted path (the
    procedure of pamr's ``pamr.cv``); K = smallest class size, at most 10."""
    x, codes, _ = _prepare(X, y)
    return cv_path(path, x, codes, folds=folds, rng=random_state)


def select_threshold(X, y, method: str = "hard", variance: str = "hetero", *,
                     offset_percent: float = 50.0, max_iter: int = 100,
                     random_state=None) -> Selection:
    """Choose the threshold by the refined ("deep") cross-validation search of
    Sahtout, Wang and Ghimire (2024): CV over the default grid, then repeated
    refinement between the neighbours of the best threshold until the number
    of selected genes cannot change. Ties go to the threshold examined last."""
    m, v = resolve_method(method, variance)
    x, codes, classes = _prepare(X, y)
    return deep_cv(x, codes, len(classes), m, v, offset_percent=offset_percent,
                   max_iter=max_iter, rng=random_state)


class HNSCClassifier(_Mixin, _Base):
    """Nearest shrunken centroid classifier with deep-CV threshold selection.

    Parameters
    ----------
    method : ``"hard"`` (default), ``"soft"``, ``"order"`` or a paper label
        (``"STh"``, ``"HTh"``, ``"OTh"``, ``"STh3"``, ``"HTh3"``, ``"OTh3"``).
    variance : ``"hetero"`` (default) or ``"homo"``. ``method="soft",
        variance="homo"`` is the original PAM classifier; ``"hard"``/``"order"``
        with ``"homo"`` are the classifiers of Sahtout, Wang and Ghimire (2024);
        ``variance="hetero"`` gives STh3/HTh3/OTh3 of Sahtout and Wang.
    threshold : fixed threshold; if None (default) it is chosen by
        :func:`select_threshold`.
    offset_percent, prior, max_iter : see :func:`train` / :func:`select_threshold`.
    random_state : seed or numpy Generator for the CV fold assignment.

    Attributes
    ----------
    classes_ : class labels
    threshold_ : threshold used
    selection_ : :class:`Selection` (None if ``threshold`` was given)
    path_ : the underlying :class:`NSCPath`
    selected_genes_ : column indices of the genes used
    n_genes_ : number of genes used
    shrunken_centroids_ : array (n_classes, n_genes)

    Examples
    --------
    >>> from hetnsc import HNSCClassifier, simulate_hetero_data
    >>> d = simulate_hetero_data(15, 20, 50, 50, p=500, a=15, random_state=1)
    >>> clf = HNSCClassifier("HTh3", random_state=0).fit(d["X_train"], d["y_train"])
    >>> err = (clf.predict(d["X_test"]) != d["y_test"]).mean()
    """

    _param_names = ("method", "variance", "threshold", "offset_percent",
                    "prior", "max_iter", "random_state")

    def __init__(self, method: str = "hard", variance: str = "hetero",
                 threshold: Optional[float] = None, offset_percent: float = 50.0,
                 prior=None, max_iter: int = 100, random_state=None):
        self.method = method
        self.variance = variance
        self.threshold = threshold
        self.offset_percent = offset_percent
        self.prior = prior
        self.max_iter = max_iter
        self.random_state = random_state

    def fit(self, X, y):
        m, v = resolve_method(self.method, self.variance)
        x, codes, classes = _prepare(X, y)
        K = len(classes)
        self.selection_ = None
        thr = self.threshold
        if thr is None:
            self.selection_ = deep_cv(x, codes, K, m, v,
                                      offset_percent=self.offset_percent,
                                      max_iter=self.max_iter,
                                      rng=self.random_state)
            thr = self.selection_.threshold
        self.path_ = _attach_classes(
            nsc_fit(x, codes, K, method=m, variance=v, threshold=[thr],
                    offset_percent=self.offset_percent, prior=self.prior,
                    remove_zeros=False, compute_prob=False), classes)
        self.classes_ = classes
        self.threshold_ = float(thr)
        self.n_features_in_ = x.shape[0]
        ds = self.path_.shrunken_delta(self.threshold_)
        self.selected_genes_ = np.nonzero(np.abs(ds).sum(axis=1) > 0)[0]
        self.n_genes_ = len(self.selected_genes_)
        self.shrunken_centroids_ = (self.path_.centroid_overall[:, None]
                                    + ds * (self.path_.sd[:, None]
                                            if v == "homo" else self.path_.sd)).T
        self.label_ = self.path_.label
        return self

    def _check(self, X):
        if not hasattr(self, "path_"):
            raise RuntimeError("This HNSCClassifier is not fitted yet.")
        x, _, _ = _prepare(X)
        if x.shape[0] != self.n_features_in_:
            raise ValueError(f"X has {x.shape[0]} genes; the classifier was "
                             f"fitted with {self.n_features_in_}.")
        return x

    def decision_function(self, X):
        """Discriminant scores -delta_k(x)/2 up to a constant (n x K);
        the predicted class has the largest score."""
        return self.path_.scores(self._check(X), self.threshold_)

    def predict(self, X):
        return self.classes_[np.argmax(self.decision_function(X), axis=1)]

    def predict_proba(self, X):
        from ._core import safe_exp
        e = safe_exp(self.decision_function(X))
        return e / e.sum(axis=1, keepdims=True)

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        if not hasattr(self, "path_"):
            return f"HNSCClassifier(method={self.method!r}, variance={self.variance!r})"
        s = (f"HNSCClassifier [{self.label_}] threshold={self.threshold_:.6g}, "
             f"genes used={self.n_genes_}")
        if self.selection_ is not None:
            s += f", CV error={self.selection_.error:.4f}"
        return s
