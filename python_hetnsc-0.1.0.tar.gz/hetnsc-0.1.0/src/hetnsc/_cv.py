"""Cross-validation and the refined ("deep") threshold search."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List, Optional

import numpy as np

from ._core import NSCPath, last_which_min, method_label, nsc_fit, r_seq


def balanced_folds(y, rng=None, nfolds: Optional[int] = None) -> List[np.ndarray]:
    """Class-balanced cross-validation folds (the fold generator of pamr).

    Parameters
    ----------
    y : array-like of class labels or integer codes.
    rng : numpy Generator, int seed or None.
    nfolds : number of folds; default ``min(smallest class size, 10)``,
        never less than 2.

    Returns
    -------
    list of integer index arrays (0-based), one per fold.
    """
    rng = np.random.default_rng(rng)
    _, codes = np.unique(np.asarray(y), return_inverse=True)
    totals = np.bincount(codes)
    if nfolds is None:
        nfolds = min(int(totals.min()), 10)
    fmax = int(totals.max())
    nfolds = max(min(nfolds, fmax), 2)
    nrow = int(np.ceil(fmax / nfolds)) * nfolds
    bigmat = np.full((nrow, len(totals)), -1, dtype=np.intp)
    for i in range(len(totals)):
        ids = np.nonzero(codes == i)[0]
        if len(ids) > 1:
            ids = rng.permutation(ids)
        bigmat[: len(ids), i] = ids
    # R: matrix(bigmat, nrow = nfolds) fills column-major
    smallmat = bigmat.reshape(-1, order="F").reshape((nfolds, -1), order="F")
    # R: permute_rows(t(smallmat)) shuffles every row of t(smallmat)
    tmat = smallmat.T.copy()
    for r in range(tmat.shape[0]):
        tmat[r] = rng.permutation(tmat[r])
    return [np.sort(col[col >= 0]) for col in tmat.T]


@dataclass
class CVResult:
    """Cross-validated error along a threshold path."""

    label: str
    threshold: np.ndarray
    size: np.ndarray        # genes kept by the full-data fit
    error: np.ndarray       # CV misclassification rate
    yhat: np.ndarray        # n x n_threshold CV predictions (class codes)
    folds: list

    def __repr__(self) -> str:
        rows = "\n".join(f"  {t:12.5g} {s:8d} {e:9.4f}"
                         for t, s, e in zip(self.threshold, self.size, self.error))
        return (f"Cross-validation for {self.label}\n"
                f"  {'threshold':>12} {'nonzero':>8} {'cv.error':>9}\n{rows}")


def cv_path(fit: NSCPath, x, y, folds=None, rng=None) -> CVResult:
    """CV along a fitted path; x is genes x samples, y integer codes."""
    n = len(y)
    K = len(fit.prior)
    if folds is None:
        folds = balanced_folds(y, rng)
    yhat = np.tile(np.asarray(y)[:, None], (1, len(fit.threshold)))
    for f in folds:
        mask = np.ones(n, dtype=bool)
        mask[f] = False
        a = nsc_fit(x[:, mask], y[mask], K, x[:, f], method=fit.method,
                    variance=fit.variance, threshold=fit.threshold,
                    offset_percent=fit.offset_percent, prior=fit.prior,
                    se_scale=fit.se_scale, remove_zeros=False,
                    sign_contrast=fit.sign_contrast, compute_prob=False)
        yhat[f, :] = a.yhat
    error = np.sum(yhat != np.asarray(y)[:, None], axis=0) / n
    return CVResult(fit.label, fit.threshold, fit.nonzero, error, yhat, folds)


@dataclass
class Selection:
    """Result of the deep cross-validation threshold search."""

    label: str
    threshold: float
    size: int
    error: float
    path: np.ndarray        # rows: threshold, size, cv error (all evaluated)

    def __repr__(self) -> str:
        return (f"Deep CV threshold search for {self.label}: threshold="
                f"{self.threshold:.6g}, genes={self.size}, CV error="
                f"{self.error:.4f} ({len(self.path)} thresholds evaluated)")


def deep_cv(x, y, K, method, variance, offset_percent=50.0, max_iter=100,
            rng=None, fold_fn: Optional[Callable] = None) -> Selection:
    """Refined threshold search of Sahtout, Wang and Ghimire (2024).

    ``fold_fn(y)`` returns a fold list for one cross-validation; by default
    new class-balanced folds are drawn from ``rng`` for every CV call, as in
    the original code.
    """
    rng = np.random.default_rng(rng)
    if fold_fn is None:
        def fold_fn(yy):
            return balanced_folds(yy, rng)
    prior = np.bincount(y, minlength=K) / len(y)

    def train(threshold=None):
        return nsc_fit(x, y, K, method=method, variance=variance,
                       threshold=threshold, offset_percent=offset_percent,
                       prior=prior)

    fit0 = train()
    cv0 = cv_path(fit0, x, y, folds=fold_fn(y))
    path = np.column_stack([cv0.threshold, cv0.size, cv0.error])
    nr = path.shape[0]
    loca = last_which_min(cv0.error)
    lo, hi = max(0, loca - 1), min(loca + 1, nr - 1)
    non_gen_dif = cv0.size[lo] - cv0.size[hi]
    if non_gen_dif > 1:
        q1 = r_seq(cv0.threshold[lo], cv0.threshold[hi], min(30, non_gen_dif))
        it = 0
        while True:
            it += 1
            fit = train(q1)
            cv = cv_path(fit, x, y, folds=fold_fn(y))
            sm = np.column_stack([cv.threshold, cv.size, cv.error])
            path = np.vstack([path, sm])
            where = last_which_min(sm[:, 2])
            lo, hi = max(0, where - 1), min(where + 1, sm.shape[0] - 1)
            cond1 = sm[lo, 1] - sm[hi, 1]
            if not (cond1 > 1 and sm.shape[0] > 2) or it >= max_iter:
                break
            q1 = r_seq(sm[lo, 0], sm[hi, 0], int(min(30, cond1)))
    best = path[last_which_min(path[:, 2])]
    return Selection(method_label(method, variance), float(best[0]),
                     int(best[1]), float(best[2]), path)
