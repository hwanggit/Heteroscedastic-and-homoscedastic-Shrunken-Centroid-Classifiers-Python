"""The Python port gives the same results as the R package hetNSC when both
use the same data and the same cross-validation folds (recorded from R).

tests/data/r_reference.json was produced by tests/data/make_r_reference.R.
"""
import json
from pathlib import Path

import numpy as np
import pytest

import hetnsc as h
from hetnsc._core import resolve_method
from hetnsc._cv import deep_cv
from hetnsc.model import _prepare

REF = json.loads((Path(__file__).parent / "data" / "r_reference.json").read_text())


def _u(v):
    return v[0] if isinstance(v, list) and len(v) == 1 else v


@pytest.mark.parametrize("key", sorted(REF["res"]))
def test_matches_r(key):
    r = REF["res"][key]
    name, label = key.split()
    d = REF["sets"][name]
    X, y = np.array(d["x"], float), np.array(d["y"])
    Xt = np.array(d["xt"], float)

    tr = h.train(X, y, label)
    np.testing.assert_allclose(tr.threshold, r["grid_threshold"], rtol=1e-12)
    np.testing.assert_array_equal(tr.nonzero, r["grid_nonzero"])
    np.testing.assert_array_equal(tr.errors, r["grid_errors"])

    folds = iter([[np.atleast_1d(np.array(f, int)) for f in fl] for fl in r["folds"]])
    x, codes, classes = _prepare(X, y)
    m, v = resolve_method(label)
    sel = deep_cv(x, codes, len(classes), m, v, fold_fn=lambda _: next(folds))
    assert sel.threshold == pytest.approx(_u(r["threshold"]), rel=1e-12)
    assert sel.size == _u(r["size"])
    assert sel.error == pytest.approx(_u(r["error"]))
    np.testing.assert_allclose(sel.path, np.array(r["path"]), rtol=1e-12)

    clf = h.HNSCClassifier(label, threshold=sel.threshold).fit(X, y)
    np.testing.assert_allclose(clf.predict_proba(Xt), np.array(r["post"]), atol=1e-10)
    assert list(clf.predict(Xt)) == r["pred"]
    assert list(clf.selected_genes_) == r["genes"]


def test_rho2_matches_r():
    d = REF["sets"]["five"]
    out = h.compute_rho2(np.array(d["x"]), d["y"])
    np.testing.assert_allclose(out["rho2_hat"], [z["rho2_hat"] for z in REF["rho"]])
    assert list(out["crossover_met"]) == [z["crossover_met"] for z in REF["rho"]]
