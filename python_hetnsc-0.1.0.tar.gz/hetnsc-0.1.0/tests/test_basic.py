import numpy as np
import pytest

import hetnsc as h

LABELS = [m[0] for m in h.methods()]


@pytest.fixture(scope="module")
def data():
    return h.simulate_hetero_data(12, 15, 20, 20, p=200, a=15, random_state=1)


def test_simulation_shapes(data):
    assert data["X_train"].shape == (27, 200)
    assert data["X_test"].shape == (40, 200)
    assert (data["y_train"] == "A").sum() == 12


@pytest.mark.parametrize("correlated", ["B", "both"])
def test_simulation_covariance(correlated):
    d = h.simulate_hetero_data(400, 400, 1, 1, ngene=5, p=10, s=np.full(10, 2.0),
                               a=0, rho=0.5, correlated=correlated, random_state=3)
    xb = d["X_train"][d["y_train"] == "B"]
    xa = d["X_train"][d["y_train"] == "A"]
    assert np.corrcoef(xb[:, :5].T).min() > 0.999          # rank-one Sigma
    np.testing.assert_allclose(xb[:, :5].var(axis=0, ddof=1), 4 * 0.5 ** np.arange(5),
                               rtol=0.2)
    assert abs(np.corrcoef(xb[:, 5], xb[:, 6])[0, 1]) < 0.2
    ra = np.corrcoef(xa[:, 0], xa[:, 1])[0, 1]
    assert (ra > 0.999) if correlated == "both" else (abs(ra) < 0.2)


@pytest.mark.parametrize("label", LABELS)
def test_train_cv_predict(data, label):
    path = h.train(data["X_train"], data["y_train"], label)
    assert path.label == label
    cv = h.cross_validate(path, data["X_train"], data["y_train"], random_state=0)
    assert len(cv.error) == len(path.threshold)
    assert np.all((cv.error >= 0) & (cv.error <= 1))
    clf = h.HNSCClassifier(label, threshold=float(path.threshold[1])).fit(
        data["X_train"], data["y_train"])
    proba = clf.predict_proba(data["X_test"])
    np.testing.assert_allclose(proba.sum(axis=1), 1)
    assert set(clf.predict(data["X_test"])) <= {"A", "B"}
    assert clf.shrunken_centroids_.shape == (2, 200)


def test_label_equals_method_variance(data):
    a = h.train(data["X_train"], data["y_train"], "OTh3")
    b = h.train(data["X_train"], data["y_train"], "order", "hetero")
    np.testing.assert_array_equal(a.nonzero, b.nonzero)
    np.testing.assert_array_equal(a.errors, b.errors)


def test_classifier_reproducible(data):
    c1 = h.HNSCClassifier("HTh3", random_state=5).fit(data["X_train"], data["y_train"])
    c2 = h.HNSCClassifier("HTh3", random_state=5).fit(data["X_train"], data["y_train"])
    assert c1.threshold_ == c2.threshold_
    assert c1.n_genes_ == len(c1.selected_genes_)
    np.testing.assert_array_equal(c1.predict(data["X_test"]), c2.predict(data["X_test"]))
    c3 = h.HNSCClassifier("HTh3", threshold=1.0).fit(data["X_train"], data["y_train"])
    assert c3.selection_ is None and c3.threshold_ == 1.0


def test_input_checks(data):
    with pytest.raises(ValueError, match="try X.T"):
        h.train(data["X_train"].T, data["y_train"])
    with pytest.raises(ValueError, match="method"):
        h.train(data["X_train"], data["y_train"], "median")
    y = data["y_train"].copy()
    y[0] = "C"
    with pytest.raises(ValueError, match="at least 2"):
        h.train(data["X_train"], y, variance="hetero")


def test_balanced_folds():
    y = np.array(["A"] * 6 + ["B"] * 9)
    folds = h.balanced_folds(y, rng=1)
    assert len(folds) == 6
    assert sorted(np.concatenate(folds)) == list(range(15))
    assert all(np.sum(y[f] == "A") == 1 for f in folds)


def test_metrics():
    cm = h.confusion_matrix(["A", "A", "B", "B"], ["A", "B", "B", "B"], ["A", "B"])
    np.testing.assert_array_equal(cm, [[1, 1], [0, 2]])
    np.testing.assert_allclose(h.per_class_recall(cm), [0.5, 1])
    assert h.balanced_accuracy(cm) == 0.75


def test_compare(data):
    res = h.compare_nsc(data["X_train"], data["y_train"], data["X_test"],
                        data["y_test"], n_runs=1, thresholding=["hard"],
                        verbose=False)
    assert res.methods == ["HTh", "HTh3"]
    rt = res.recall_table()
    s = res.summary()
    np.testing.assert_allclose(np.mean(rt["recall_HTh"]), s["balanced_accuracy"][0])


def test_sklearn_compat(data):
    sk = pytest.importorskip("sklearn")
    from sklearn.base import clone
    from sklearn.model_selection import cross_val_score
    clf = clone(h.HNSCClassifier("STh3", random_state=0))
    scores = cross_val_score(clf, data["X_train"], data["y_train"], cv=3)
    assert len(scores) == 3
