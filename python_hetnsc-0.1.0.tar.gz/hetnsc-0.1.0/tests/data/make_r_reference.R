# Regenerates tests/data/r_reference.json with the R package hetNSC:
#   Rscript make_r_reference.R r_reference.json

suppressMessages({library(hetNSC); library(jsonlite)})
out <- commandArgs(TRUE)[1]
rec <- new.env(); rec$folds <- list()
trace(hetNSC:::balanced_folds, exit = quote(assign("folds",
      c(get("folds", envir = rec), list(lapply(returnValue(), function(f) f - 1L))),
      envir = rec)), print = FALSE, where = asNamespace("hetNSC"))
make <- function(seed, K, n, p, nte) {
  set.seed(seed)
  labs <- letters[1:K]
  gen <- function(lab) vapply(lab, function(l) { k <- match(l, labs)
    rnorm(p, mean = c(rep(k * 0.5, 15), rep(0, p - 15)), sd = 2 * k - 1) }, numeric(p))
  y <- rep(labs, n); x <- gen(y); xt <- gen(rep(labs, nte))
  list(x = x, y = y, xt = xt, yt = rep(labs, nte))
}
sets <- list(three = make(3, 3, c(8, 12, 10), 200, 4),
             five  = make(11, 5, c(6, 9, 5, 12, 7), 150, 2))
res <- list()
for (nm in names(sets)) {
  d <- sets[[nm]]
  for (m in hnsc_methods()$label) {
    tr <- hnsc_train(d$x, d$y, method = m)
    rec$folds <- list(); set.seed(77)
    fit <- hnsc(d$x, d$y, method = m)
    res[[paste(nm, m)]] <- list(
      grid_threshold = tr$threshold, grid_nonzero = tr$nonzero, grid_errors = tr$errors,
      folds = rec$folds, threshold = fit$selection$threshold, size = fit$selection$size,
      error = fit$selection$error, path = unname(fit$selection$path),
      post = unname(predict(fit, d$xt, type = "posterior")),
      pred = as.character(predict(fit, d$xt)), genes = fit$selected.genes - 1L)
  }
  sets[[nm]] <- lapply(d, function(v) if (is.matrix(v)) unname(t(v)) else v)  # samples x genes
}
rho <- compute_rho2(t(sets$five$x), sets$five$y)
write_json(list(sets = sets, res = res, rho = rho), out, digits = NA, matrix = "rowmajor")
